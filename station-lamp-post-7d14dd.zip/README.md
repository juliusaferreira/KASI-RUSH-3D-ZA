# Station Lamp Post

https://polyfork.dev/asset/station-lamp-post-7d14dd

A parametric low-poly model for three.js. One import, no loader, no textures,
one draw call. `createAsset()` returns a ready `THREE.Group`.

## What is in this folder

| file | what it is |
| --- | --- |
| `index.html` | a complete working page: **double-click it** |
| `station-lamp-post-7d14dd.mjs` | the model as an ES module, with every option below |
| `station-lamp-post-7d14dd.glb` | the same model baked, for Unity, Godot, Blender and glTF loaders |
| `LICENSE.txt` | the terms, in short: use it commercially, do not resell it, do not build a commercial asset generator from it |

## Run it

Double-click `index.html`. It needs an internet connection the first time,
because three.js is pulled from unpkg.com.

It carries its own copy of the model code so that it works from a `file://`
URL, where browsers refuse to load ES modules. If you would rather edit
`station-lamp-post-7d14dd.mjs` and see the page pick up your changes, serve the folder
and it will import the file instead of the copy:

```
python3 -m http.server     # then open http://localhost:8000
```

## Use it in your own scene

```js
import { createAsset } from './station-lamp-post-7d14dd.mjs';
scene.add(createAsset());
```

The bare `three` specifiers resolve through any bundler (Vite, webpack, esbuild),
or through an importmap in your page:

```html
<script type="importmap">
{ "imports": { "three": "https://unpkg.com/three@0.180.0/build/three.module.js",
               "three/addons/": "https://unpkg.com/three@0.180.0/examples/jsm/" } }
</script>
```

Prefer the GLB? `new GLTFLoader().load('station-lamp-post-7d14dd.glb', g => scene.add(g.scene))`.
The module is the smaller and more flexible of the two: it carries the options
below, the GLB is one frozen configuration of them.

## Options

```js
createAsset({
  colorway: 'black-iron',
  post: 'concrete',
  height: 3.5,
  plinth: false,
  wear: 0.3,
  iron: '#2d2925',
  roof: '#7c766b',
  shaft: '#3f4140',
  glass: '#f2f2ec',
  concrete: '#968d84',
  timber: '#715f50',
  rust: '#774034',
});
```

| option | type | default | accepts | what it does |
| --- | --- | --- | --- | --- |
| `colorway` | choice | `'black-iron'` | `'black-iron'`, `'station-green'`, `'green-cream'`, `'brown-cream'`, `'works-grey'` | Curated railway paint. black-iron (the reference): near-black ironwork (lantern frame, neck, crossbar), a grey lantern roof and a grey concrete post. station-green: deep green ironwork under a charcoal roof. green-cream: the same green under a cream roof, and a cast-iron post's fluted shaft painted cream. brown-cream: chocolate-brown ironwork with the cream roof and shaft, the kit's cream-and-brown station livery. works-grey: charcoal ironwork, a grey roof and shaft and a sandier concrete. The pale glass, the timber and the rust that wear brings out are the same in all five. |
| `post` | choice | `'concrete'` | `'cast-iron'`, `'timber'`, `'concrete'` | What carries the lantern. concrete (the reference): a plain precast concrete post with chamfered arrises, 0.24 m square at the foot tapering to 0.175 m under the neck, a square iron collar where the crossbar passes through. cast-iron (the main station's): a bolted flange, a wide 12-sided lower sleeve 0.225 m across to 0.70 m up, a short cone and a slimmer shaft with six deep flutes, a six-sided collar round the crossbar. timber (the halt's): a bolted flange and a square iron shoe 0.35 m tall holding a chamfered square timber post 0.16 m across, a square iron band round the crossbar. The lantern, roof, neck, crossbar and overall height are the same for all three. |
| `height` | range | `3.5` | `3` to `4.2` | Height to the tip of the finial in metres. REBUILT, not scaled: only the post between its foot (or the cast-iron sleeve) and the neck lengthens; its foot and top sections, the flange, sleeve, plinth, the 0.95 m lamp head and the crossbar 1.1 m under the finial keep their size and spacing, so the lantern rides up with its crossbar. 3.0 is a low halt lamp with the lantern bottom about 2.2 m up, 3.5 the reference, 4.2 a tall lamp over a busy platform. |
| `plinth` | toggle | false | `true`, `false` | Off (the reference): the post stands straight on the ground or a platform deck at y = 0 (the concrete post planted, the cast-iron and timber posts on their bolted flange). On: a low concrete block 0.62 m square and 0.17 m tall with a broad chamfered top under the post; the post shortens by the block's height, so the lantern and finial stay at the same height. |
| `wear` | range | `0.3` | `0` to `1` | 0 freshly painted and new, 1 old and weathered: faded paint, dirt, rust and small chips; the object itself never changes. |
| `iron` | color | `'#2d2925'` | any hex or `THREE.Color` | Albedo of the painted iron: the lantern frame (corner posts, top and bottom bands, bottom plate), the neck and its collar, the vent block, cap plate and finial, the crossbar with its knobs and collar, the cast-iron sleeve and cone, the flanges, bosses and bolts, and the timber post's shoe and bands. Rust replaces it face by face as wear rises; above wear 0.3 the paint weathers toward a rusty dark brown. |
| `roof` | color | `'#7c766b'` | any hex or `THREE.Color` | Albedo of the lantern's hipped roof: its four slopes, the eave band and the soffit under it. Lighter than the ironwork in the reference. Above wear 0.3 it fades and its eave band rusts through in places; the slopes themselves never turn wholly to rust. |
| `shaft` | color | `'#3f4140'` | any hex or `THREE.Color` | Albedo of the fluted cast-iron shaft from the cone up to the neck (post: cast-iron only): charcoal or green to match the ironwork, cream or grey for a two-tone livery. Above wear 0.3 it fades. Never rusts. |
| `glass` | color | `'#f2f2ec'` | any hex or `THREE.Color` | Daytime albedo of the four opal panes of the lantern, one a face. This is the part's ONLY lit zone: after dark the glass glows warm lamp amber. No other zone wears it in any colorway and wear never changes it. |
| `concrete` | color | `'#968d84'` | any hex or `THREE.Color` | Albedo of the precast concrete: the concrete post (post: concrete) and, when it is on, the plinth block with its chamfered top and cut corners. Above wear 0.3 it darkens with dirt. Never rusts. |
| `timber` | color | `'#715f50'` | any hex or `THREE.Color` | Albedo of the square timber post (post: timber only). Above wear 0.3 it greys toward weathered timber. |
| `rust` | color | `'#774034'` | any hex or `THREE.Color` | Albedo of the rust wear brings through the iron paint face by face: from early wear the flange bolts and the crossbar's knobs; above 0.3 the bar and its collar, the neck collar, the flange and shoe, the lantern's bottom band and plate, then its corner posts and top band, the vent block, cap plate, finial and the roof's eave band. None at wear 0, next to none at the default 0.3, about a quarter of the iron faces at 1 over iron weathered brown. |

## Specs

336 triangles, 1 material, 0.72 × 3.5 × 0.51 m, real-world scale.

## Building this with an AI agent?

Point it at https://polyfork.dev/prompt.txt: the whole catalogue as working
instructions, no key needed to browse. There is an MCP server too, at https://polyfork.dev/mcp.

## License

Personal and commercial use: games, apps, websites, client work.
Modify freely, no attribution required. Do not resell or redistribute the files
themselves as assets, or use them to build or train a COMMERCIAL asset
generator: a model, service or pipeline that produces 3D assets and that you
sell or offer to others. Personal experiments, research and learning are fine.
Breaking these terms can end your license and your access, without a refund.

Full terms: https://polyfork.dev/licensing
